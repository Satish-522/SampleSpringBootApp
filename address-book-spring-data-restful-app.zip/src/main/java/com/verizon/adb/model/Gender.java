package com.verizon.adb.model;

public enum Gender {
	MALE,FEMALE;

}
